JUNIORSTATS U12 – FIREBASE VERZE 2
===================================

CO TATO VERZE UMÍ
-----------------
- Zachovává původní rozhraní a původní moduly aplikace.
- Přihlášení trenéra a rodiče používá Firebase Authentication (e-mail/heslo).
- Role a skupina se načítají z Firestore users/{uid}.
- Trenér při prvním přihlášení přenese data z localStorage do Firestore.
- Týmová data se ukládají do kolekce appData (jeden dokument pro každý klíč).
- Rodiče mají týmová data pouze pro čtení.
- Rodič může odeslat docházku jen pro hráče přiřazené k jeho účtu.
- Trenér uvidí příchozí potvrzení v aplikaci; potvrzení se předvyplní do docházky
  a trenér zkontroluje a uloží trénink.

DŮLEŽITÉ OMEZENÍ
----------------
Toto je integrační/testovací verze, nikoli ověřený produkční systém. Před použitím
s reálnými rodiči a osobními údaji musí být otestováno přihlášení, migrace,
pravidla Firestore, souběžné zápisy a všechny moduly aplikace. Data jsou v
Firestore synchronizována po jednotlivých klíčích localStorage; starší moduly
nebyly kompletně přepsány na nativní dokumentový model. Při souběžných změnách
stejného klíče může dojít k přepsání celé hodnoty. Pro produkční nasazení je
doporučeno později rozdělit klíče na kolekce (players, attendance, matches…).

NASTAVENÍ FIREBASE
------------------
1. Vytvořte samostatný Firebase projekt pro tuto skupinu (např. juniorstats-u12).
2. Přidejte aplikaci typu Web a zkopírujte její firebaseConfig do firebase-config.js.
   Soubor musí být ve stejné složce/originu jako index.html.
3. Authentication > Sign-in method: zapněte Email/Password.
4. Authentication > Settings: přidejte doménu, na které aplikaci hostujete,
   do Authorized domains.
5. Firestore Database: vytvořte databázi v regionu Europe.
6. Firestore > Rules: vložte obsah souboru firestore.rules a publikujte.
7. Authentication > Users: vytvořte nejprve účet trenéra.
8. Otevřete detail uživatele, zkopírujte jeho UID. Ve Firestore vytvořte dokument
   users/{UID} s tímto obsahem:
     {
       "role": "trainer",
       "groupId": "u12",
       "active": true
     }
9. První přihlášení trenéra musí proběhnout v tom samém prohlížeči a na stejné
   webové adrese/originu, kde jsou uložena původní data týmu. Tím se data
   z původního localStorage přenesou do Firestore. Nevymažte původní web ani
   data prohlížeče před dokončením migrace.
10. Po úspěšné migraci vytvořte rodičovské účty v Authentication > Users.
11. Pro každého rodiče vytvořte users/{UID}:
     {
       "role": "parent",
       "groupId": "u12",
       "active": true,
       "playerIds": ["ID_HRACE"]
     }
    ID_HRACE musí přesně odpovídat data-id hráče v aplikaci. Pokud má rodič
    přístup ke dvěma sourozencům, vložte oba identifikátory do pole playerIds.

POZNÁMKY K MIGRACI
------------------
- První migraci spouští trenér, ne rodič.
- Pokud aplikaci nasadíte na jinou doménu/cestu, localStorage nemusí být stejný.
  V takovém případě nepřihlašujte trenéra, dokud nejsou původní data bezpečně
  exportována nebo dostupná na stejné adrese.
- Firebase Web API key není tajemství. Nikdy nevkládejte service-account JSON
  nebo privátní klíče do webové aplikace.
- Při chybě migrace se vraťte k původní kopii a nekonfigurujte rodičovské účty.

VERZE 3 – OPRAVY
----------------
- Rodičovské potvrzení už nepřepisuje týmovou docházku přímo.
- Trenér musí potvrzení ručně zkontrolovat a přijmout.
- Přenos starých dat vyžaduje výslovné potvrzení.
- Příchozí synchronizace se neposílá zpět do Firestore.
- Není dokončené testování na skutečném Firebase projektu ani všech obrazovek.
- Zatím není určeno k ostrému provozu s osobními údaji dětí.


VERZE 4 – CORECTII TEHNICE MINIME
--------------------------------
- Profilul trebuie să aibă explicit active: true; profilurile incomplete nu mai pot intra.
- Inițializarea stratului Firestore este protejată împotriva pornirii simultane de două ori
  (de exemplu, în timpul autentificării și al evenimentului onAuthStateChanged).
- Acceptarea confirmărilor părinților inițializează în siguranță obiectul de prezență dacă
  acesta lipsește în memoria paginii.

Interfața și modulele aplicației originale nu au fost redesenate.
Aceste corecții nu înlocuiesc testarea pe un proiect Firebase real.


VERZE 5 – GESTIONE CORECTA A SESIUNII FIREBASE
---------------------------------------------
- La deconectare se opresc listener-ele Firestore.
- Se anuleaza scrierile amanate care ar putea ramane de la contul anterior.
- La autentificarea altui cont/grup/rol se initializeaza un data layer nou.
- Un cont nou nu mai poate reutiliza accidental listener-ele si starea contului anterior.
- groupId trebuie sa fie text valid si este normalizat.

Interfata si fluxurile vizibile ale aplicatiei nu au fost schimbate.
Validarea sintaxei nu echivaleaza cu testarea Firebase in browser.


VERZE 6 – ODDELENI SOUKROMYCH UDAJU
----------------------------------
- Klíč juniorstats_ratings se ukládá do kolekce trainerPrivateData.
- Kolekci trainerPrivateData může číst a měnit pouze aktivní trenér dané skupiny.
- Rodiče nadále čtou běžná týmová data z appData, aby původní obrazovky zůstaly funkční.
- Při přihlášení trenéra se případný starý dokument juniorstats_ratings z appData
  přesune do trainerPrivateData a starý dokument se smaže.
- Pravidla Firestore zakazují ukládání hodnocení do rodičům dostupné kolekce.

DŮLEŽITÁ MIGRACE PRAVIDEL
-------------------------
Pokud už jsou data ve Firestore z verze 2–5:
1. Nejprve publikujte nová pravidla z tohoto balíčku.
2. Přihlaste se jako trenér. Aplikace přesune starý dokument hodnocení z appData
   do trainerPrivateData.
3. Teprve po úspěšném přihlášení a synchronizaci vytvořte/testujte rodičovské účty.
Rodičovský dotaz výslovně vynechává klíč juniorstats_ratings.

Toto řešení odděluje klíč hodnocení. Neznamená to, že je celý systém již
produkčně auditován; pravidla a přihlášení je nutné otestovat v Firebase.


VERZE 7 – BEZPECNEJSI MIGRACE A ZAPISY
-------------------------------------
- Prvni migrace pouziva soukromy marker appMeta/{groupId}.
- Data z localStorage se doplnuji pouze pro klice, ktere v cloudu chybi.
  Existujici cloudove hodnoty se pri migraci neprepisuji.
- Opozděny zapis si zachova UID, groupId a instanci databaze z okamziku
  naplanovani a pred ulozenim overi, ze je stale prihlaseny stejny trener.
- ID hracu v profilu rodice se normalizuji na text.
- Pravidla parentSubmissions kontroluji povolene hodnoty dochazky a shodu
  playerIds s klici statuses.
- Kolekce appMeta je pristupna pouze aktivnimu trenerovi dane skupiny.

POZNAMKA
--------
Tato verze stale vyzaduje test pravidel v Firebase Emulatoru a realny test
prihlaseni/synchronizace na dvou zarizenich. Automaticky test emulatoru nebyl
v tomto prostredi spusten. UI a puvodni funkce nebyly zamerne redesignovany.

- V dokumentu users/{UID} ukladejte playerIds jako textove hodnoty, napr. ["17"], nikoli jako cisla.


VERZE 8 – DOROVNANI REALTIME SYNCHRONIZACE
-----------------------------------------
- Realtime listener sdilenych dat nyní porovnava cely aktualni snapshot,
  nepreskakuje prvni snapshot.
- Tim se resi zavod mezi prvnim nactenim dat a pripojenim realtime listeneru.
- Pri prichodu noveho snapshotu se lokalni klice porovnaji s online stavem;
  zmeny a odstraneni se promítnou do lokalniho uloziste a stary modul se znovu
  vykresli.
- Stejne dorovnani plati pro soukroma hodnoceni trenera.

Kontrola: vlozeny JavaScript prosiel `node --check`.
Omezeni: Firestore Security Rules nebyly spusteny ve Firebase Emulatoru a
neprobehla realna synchronizace na dvou telefonech. To vyzaduje Firebase projekt.


VERZE 9 – OPRAVA ODSTRANENI DAT
-------------------------------
- Pri odstraneni localStorage klice se nejprve zrusi pripadny cekajici
  debounced zapis pro stejny klic.
- Tim se zabrani tomu, aby casovac po odstraneni znovu vytvoril cloudovy
  dokument, ktery uz uzivatel smazal.
- Mazani probiha pouze pro aktivni prihlasenou relaci trenera.


VERZE 10 – OCHRANA ROZPRACOVANYCH ZMEN PRI REALTIME SYNCHRONIZACI
------------------------------------------------------------------
- Realtime snapshot nesmi prepsat lokalni hodnotu, pro kterou prave bezi
  odlozeny zapis.
- Snapshot nesmi znovu vytvorit lokalni klic, ktery uzivatel prave maze.
- Pri mazani se eviduje cekajici delete az do potvrzeni Firestore.
- Nova lokalni hodnota zrusi cekajici delete pro stejny klic.
- Ochrana plati i pro soukroma hodnoceni trenera.


VERSIUNEA 11 – PROTECȚIE SUPLIMENTARĂ LA SALVARE
- Modificările în așteptare sunt păstrate într-o coadă până când Firestore confirmă salvarea.
- La ascunderea paginii, la pagehide și la revenirea conexiunii se încearcă trimiterea imediată a modificărilor rămase.
- Dacă salvarea eșuează, valoarea locală rămâne în coadă și se reîncearcă la reconectare.
- Sincronizarea în timp real nu mai suprascrie o cheie cât timp salvarea ei este în așteptare.
- Ștergerea anulează și valoarea aflată în coada de salvare, pentru a evita recrearea documentului.

IMPORTANT:
- Evenimentele pagehide/visibilitychange nu pot garanta finalizarea unei cereri de rețea dacă browserul închide procesul imediat. Pentru date critice este obligatoriu testul pe două dispozitive și cu internet întrerupt.
- Nu s-a putut testa Firestore fără configurația și proiectul Firebase reale.
- Verificarea Node.js confirmă doar sintaxa JavaScript, nu funcționarea autentificării, regulilor sau sincronizării.

VERSIUNEA 12 – RETRY PENTRU ȘTERGERI
- Dacă ștergerea unui document Firestore eșuează, aplicația nu mai elimină imediat protecția locală care împiedică reapariția datelor.
- Operația de ștergere rămâne în așteptare și este reîncercată la revenirea conexiunii sau când pagina devine ascunsă.
- Dacă se introduce din nou o valoare pentru aceeași cheie, operația veche de ștergere este anulată.
